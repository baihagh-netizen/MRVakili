package com.pension.calc;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.print.PrintAttributes;
import android.print.PrintManager;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
  private WebView webView;

  @SuppressLint("SetJavaScriptEnabled")
  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    webView = new WebView(this);
    setContentView(webView);

    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    s.setSupportZoom(false);
    s.setBuiltInZoomControls(false);
    s.setDisplayZoomControls(false);
    // Reduce easy source inspection / selection
    s.setAllowFileAccessFromFileURLs(false);
    s.setAllowUniversalAccessFromFileURLs(false);

    webView.setLongClickable(false);
    webView.setHapticFeedbackEnabled(false);
    webView.setOnLongClickListener(v -> true);
    webView.setOnCreateContextMenuListener(null);

    webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
    webView.addJavascriptInterface(new ExitBridge(), "AndroidExit");
    webView.setWebChromeClient(new WebChromeClient());
    webView.loadUrl("file:///android_asset/index.html");
  }

  public class PrintBridge {
    private final Context context;
    PrintBridge(Context c) { context = c; }
    @JavascriptInterface
    public void printPage() {
      runOnUiThread(() -> {
        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        if (pm != null) {
          String job = "گزارش مستمری";
          pm.print(job, webView.createPrintDocumentAdapter(job),
              new PrintAttributes.Builder()
                  .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                  .setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                  .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                  .build());
        }
      });
    }
  }

  public class ExitBridge {
    @JavascriptInterface
    public void close() {
      runOnUiThread(() -> finishAffinity());
    }
  }

  @Override
  public void onBackPressed() {
    if (webView != null && webView.canGoBack()) webView.goBack();
    else super.onBackPressed();
  }
}
