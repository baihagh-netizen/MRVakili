package com.pension.calc;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.print.PrintAttributes;
import android.print.PrintManager;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }
    public class PrintBridge {
        private final Context context;
        PrintBridge(Context c) { context = c; }
        @JavascriptInterface public void printPage() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
                if (pm != null) {
                    String job = "گزارش مستمری";
                    pm.print(job, webView.createPrintDocumentAdapter(job),
                        new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setResolution(new PrintAttributes.Resolution("pdf","PDF",300,300))
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                }
            });
        }
    }
    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("resultBack()", null);
        else super.onBackPressed();
    }
}
